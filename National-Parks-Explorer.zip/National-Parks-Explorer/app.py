import sqlite3
import random
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, g

app = Flask(__name__)
DATABASE = 'database.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        cursor = db.cursor()
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            username TEXT NOT NULL UNIQUE,
            card_number TEXT,
            card_expiry TEXT,
            card_cvv TEXT
        )''')
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS banks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            username TEXT NOT NULL UNIQUE
        )''')
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS bills (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER,
            bill_type TEXT,
            amount REAL,
            paid_date DATE,
            status TEXT,
            FOREIGN KEY(customer_id) REFERENCES customers(id)
        )''')
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS savings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER,
            amount REAL,
            date DATE,
            FOREIGN KEY(customer_id) REFERENCES customers(id)
        )''')

        cursor.execute('''CREATE TABLE IF NOT EXISTS upi_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER,
            amount REAL,
            date DATE,
            transaction_type TEXT,
            FOREIGN KEY(customer_id) REFERENCES customers(id)
        )''')

        cursor.execute('''CREATE TABLE IF NOT EXISTS loan_applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER,
            bank_id INTEGER,
            amount REAL,
            purpose TEXT,
            status TEXT DEFAULT 'Pending',
            date DATE,
            score INTEGER,
            likelihood TEXT,
            repaid_amount REAL DEFAULT 0,
            FOREIGN KEY(customer_id) REFERENCES customers(id),
            FOREIGN KEY(bank_id) REFERENCES banks(id)
        )''')
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS loan_decisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            application_id INTEGER,
            bank_id INTEGER,
            decision TEXT,
            notes TEXT,
            date DATE,
            FOREIGN KEY(application_id) REFERENCES loan_applications(id)
        )''')
        
        cursor.execute("SELECT count(*) FROM customers")
        if cursor.fetchone()[0] == 0:
            seed_data(cursor)
            
        db.commit()

def seed_data(cursor):
    # Insert customers (exact data from user spec)
    customers = [
        ('Asha R', '9876543210', 'asha', '5555444433332222', '02/26', '123'),
        ('Meena S', '9876540001', 'meena', '4444333322221111', '12/25', '234'),
        ('Lakshmi N', '9876509999', 'lakshmi', '3333222211110000', '09/27', '345'),
        ('Priya D', '9898981212', 'priya', '2222111100009999', '08/26', '456'),
        ('Saranya K', '9123456780', 'saranya', '1111000099998888', '11/28', '567')
    ]
    cursor.executemany("INSERT INTO customers (name, phone, username, card_number, card_expiry, card_cvv) VALUES (?, ?, ?, ?, ?, ?)", customers)
    
    # Insert banks
    banks = [('Bharat Micro Bank', 'bharat'), ('Jan Dhan Co-Op Bank', 'jandhan')]
    cursor.executemany("INSERT INTO banks (name, username) VALUES (?, ?)", banks)
    
    # Insert loan applications with exact mock data
    loan_apps = [
        (1, 1, 15000, 'Shop expansion', 'Approved', '2024-10-15', 82, 'High likelihood — recommended', 0),
        (2, 2, 8000, 'Medical needs', 'Pending', '2024-10-14', 61, 'Moderate likelihood — caution', 0),
        (3, 1, 10000, 'Education', 'Rejected', '2024-10-13', 45, 'Moderate likelihood — caution', 0),
        (4, 2, 12000, 'Small business', 'Pending', '2024-10-12', 33, 'Low likelihood — do not approve', 0),
    ]
    for loan in loan_apps:
        cursor.execute("INSERT INTO loan_applications (customer_id, bank_id, amount, purpose, status, date, score, likelihood, repaid_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", loan)
    
    # Insert UPI transactions with specific receivers
    upi_txns = [
        (1, 'shop@upi', 150, '2024-10-11'),
        (1, 'milk@upi', 80, '2024-10-13'),
        (2, 'rent@upi', 200, '2024-10-14'),
        (3, 'water@upi', 60, '2024-10-10'),
        (4, 'friend@upi', 100, '2024-10-12'),
    ]
    for txn in upi_txns:
        cursor.execute("INSERT INTO upi_transactions (customer_id, amount, date, transaction_type) VALUES (?, ?, ?, 'Payment')", (txn[0], txn[2], txn[3]))
    
    # Insert savings with specific amounts
    savings = [
        (1, 100, '2024-10-01'),
        (1, 120, '2024-10-08'),
        (2, 50, '2024-10-02'),
        (3, 30, '2024-10-05'),
        (4, 20, '2024-10-07'),
    ]
    cursor.executemany("INSERT INTO savings (customer_id, amount, date) VALUES (?, ?, ?)", savings)
    
    # Insert bills with specific statuses
    bills = [
        (1, 'Electricity', 500, '2024-09-05', 'Paid'),
        (1, 'Water', 120, '2024-09-08', 'Paid'),
        (2, 'LPG', 900, '2024-09-09', 'Late'),
        (3, 'Electricity', 450, '2024-09-11', 'Missed'),
        (4, 'Water', 110, '2024-09-10', 'Paid'),
        (1, 'Mobile', 299, '2024-10-01', 'Paid'),
        (2, 'Electricity', 600, '2024-10-02', 'Paid'),
        (3, 'Water', 140, '2024-10-03', 'Late'),
        (5, 'Internet', 499, '2024-10-04', 'Paid'),
        (5, 'Mobile', 250, '2024-10-05', 'Paid'),
    ]
    cursor.executemany("INSERT INTO bills (customer_id, bill_type, amount, paid_date, status) VALUES (?, ?, ?, ?, ?)", bills)

def calculate_score(customer_id):
    db = get_db()
    cursor = db.execute("SELECT count(*), sum(CASE WHEN status='Paid' THEN 1 ELSE 0 END) FROM bills WHERE customer_id=?", (customer_id,))
    total_bills, paid_bills = cursor.fetchone()
    bill_score = (paid_bills / total_bills * 100) if total_bills > 0 else 0
    
    cursor = db.execute("SELECT avg(amount) FROM savings WHERE customer_id=?", (customer_id,))
    avg_saving = cursor.fetchone()[0] or 0
    savings_score = min(100, (avg_saving / 2000) * 100)
    
    upi_score = random.randint(50, 100)
    trust_score = 80
    
    total = (bill_score * 0.4) + (savings_score * 0.3) + (upi_score * 0.2) + (trust_score * 0.1)
    
    likelihood = "Low likelihood — do not approve"
    if total >= 70:
        likelihood = "High likelihood — recommended"
    elif total >= 40:
        likelihood = "Moderate likelihood — caution"
        
    return int(total), likelihood

def get_readiness_level(score):
    if score >= 90:
        return "Prime Borrower"
    elif score >= 70:
        return "Ready"
    elif score >= 40:
        return "Improving"
    else:
        return "Low"

def get_improvement_suggestions(score):
    if score < 40:
        return [
            "Pay utility bills before due date.",
            "Maintain small weekly savings.",
            "Use UPI more frequently to show financial activity."
        ]
    elif score < 70:
        return [
            "Increase savings incrementally.",
            "Join SHG/cooperative to build trust signals.",
            "Maintain consistent bill payment records."
        ]
    else:
        return [
            "You are nearly ready for formal micro-credit!",
            "Consider applying for higher loan amounts.",
            "Keep maintaining excellent payment habits."
        ]

def get_savings_chart_data(customer_id):
    db = get_db()
    savings = db.execute("SELECT date, amount FROM savings WHERE customer_id=? ORDER BY date DESC LIMIT 12", (customer_id,)).fetchall()
    if not savings:
        return [], []
    dates = [s['date'] for s in reversed(savings)]
    amounts = [s['amount'] for s in reversed(savings)]
    return dates, amounts

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login-customer', methods=['GET', 'POST'])
def login_customer():
    if request.method == 'POST':
        username = request.form['username']
        db = get_db()
        cursor = db.execute("SELECT id FROM customers WHERE username=?", (username,))
        user = cursor.fetchone()
        if user:
            return redirect(url_for('dashboard_customer', customer_id=user['id']))
    return render_template('login_customer.html')

@app.route('/login-bank', methods=['GET', 'POST'])
def login_bank():
    if request.method == 'POST':
        username = request.form['username']
        db = get_db()
        cursor = db.execute("SELECT id FROM banks WHERE username=?", (username,))
        user = cursor.fetchone()
        if user:
            return redirect(url_for('dashboard_bank', bank_id=user['id']))
    return render_template('login_bank.html')

@app.route('/dashboard-customer/<int:customer_id>')
def dashboard_customer(customer_id):
    score, likelihood = calculate_score(customer_id)
    readiness = get_readiness_level(score)
    suggestions = get_improvement_suggestions(score)
    chart_dates, chart_amounts = get_savings_chart_data(customer_id)
    
    db = get_db()
    bills = db.execute("SELECT * FROM bills WHERE customer_id=? ORDER BY paid_date DESC", (customer_id,)).fetchall()
    savings = db.execute("SELECT * FROM savings WHERE customer_id=? ORDER BY date DESC", (customer_id,)).fetchall()
    upi_trans = db.execute("SELECT * FROM upi_transactions WHERE customer_id=? ORDER BY date DESC LIMIT 10", (customer_id,)).fetchall()
    loans = db.execute("SELECT l.*, b.name as bank_name FROM loan_applications l LEFT JOIN banks b ON l.bank_id = b.id WHERE l.customer_id=? ORDER BY l.date DESC", (customer_id,)).fetchall()
    customer = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
    
    banks = db.execute("SELECT id, name FROM banks").fetchall()
    return render_template('dashboard_customer.html', customer=customer, score=score, likelihood=likelihood, 
                         readiness=readiness, suggestions=suggestions, chart_dates=chart_dates, 
                         chart_amounts=chart_amounts, bills=bills, savings=savings, upi_trans=upi_trans, loans=loans, banks=banks)

@app.route('/add-savings/<int:customer_id>', methods=['POST'])
def add_savings(customer_id):
    amount = request.form['amount']
    date = datetime.now().strftime('%Y-%m-%d')
    db = get_db()
    db.execute("INSERT INTO savings (customer_id, amount, date) VALUES (?, ?, ?)", (customer_id, amount, date))
    db.commit()
    return redirect(url_for('dashboard_customer', customer_id=customer_id))

@app.route('/upi-payment/<int:customer_id>/<int:amount>', methods=['POST'])
def upi_payment(customer_id, amount):
    date = datetime.now().strftime('%Y-%m-%d')
    db = get_db()
    db.execute("INSERT INTO upi_transactions (customer_id, amount, date, transaction_type) VALUES (?, ?, ?, ?)", 
               (customer_id, amount, date, 'Payment'))
    db.commit()
    return redirect(url_for('dashboard_customer', customer_id=customer_id))

@app.route('/apply-loan/<int:customer_id>', methods=['GET', 'POST'])
def apply_loan(customer_id):
    if request.method == 'POST':
        amount = request.form['amount']
        purpose = request.form['purpose']
        bank_id = request.form.get('bank_id', 1)
        score, likelihood = calculate_score(customer_id)
        date = datetime.now().strftime('%Y-%m-%d')
        
        db = get_db()
        db.execute("INSERT INTO loan_applications (customer_id, bank_id, amount, purpose, date, score, likelihood) VALUES (?, ?, ?, ?, ?, ?, ?)",
                   (customer_id, bank_id, amount, purpose, date, score, likelihood))
        db.commit()
        return render_template('loan_submitted.html', customer_id=customer_id)
    
    db = get_db()
    banks = db.execute("SELECT id, name FROM banks").fetchall()
    return render_template('apply_loan.html', customer_id=customer_id, banks=banks)

@app.route('/repay-loan/<int:loan_id>/<int:customer_id>/<int:amount>', methods=['POST'])
def repay_loan(loan_id, customer_id, amount):
    db = get_db()
    db.execute("UPDATE loan_applications SET repaid_amount = repaid_amount + ? WHERE id=?", (amount, loan_id))
    db.commit()
    return redirect(url_for('dashboard_customer', customer_id=customer_id))

@app.route('/dashboard-bank/<int:bank_id>')
def dashboard_bank(bank_id):
    db = get_db()
    applications = db.execute('''
        SELECT l.*, c.name, c.phone 
        FROM loan_applications l 
        JOIN customers c ON l.customer_id = c.id
        WHERE l.bank_id = ?
        ORDER BY l.date DESC
    ''', (bank_id,)).fetchall()
    
    loans_tracking = db.execute('''
        SELECT l.*, c.name, 
               CASE WHEN l.repaid_amount >= l.amount THEN 'Cleared'
                    WHEN l.status = 'Approved' THEN 'On Track'
                    ELSE 'Pending' END as repayment_status
        FROM loan_applications l
        JOIN customers c ON l.customer_id = c.id
        WHERE l.bank_id = ? AND l.status = 'Approved'
        ORDER BY l.date DESC
    ''', (bank_id,)).fetchall()
    
    heatmap_data = [
        {'region': 'Chennai', 'score_avg': 62},
        {'region': 'Bangalore', 'score_avg': 72},
        {'region': 'Mumbai', 'score_avg': 55},
        {'region': 'Delhi', 'score_avg': 68},
        {'region': 'Kolkata', 'score_avg': 58},
    ]
    
    return render_template('dashboard_bank.html', bank_id=bank_id, applications=applications, 
                         loans_tracking=loans_tracking, heatmap_data=heatmap_data)

@app.route('/loan-details/<int:loan_id>/<int:bank_id>', methods=['GET', 'POST'])
def loan_details(loan_id, bank_id):
    db = get_db()
    if request.method == 'POST':
        decision = request.form['decision']
        notes = request.form.get('notes', '')
        date = datetime.now().strftime('%Y-%m-%d')
        db.execute("INSERT INTO loan_decisions (application_id, bank_id, decision, notes, date) VALUES (?, ?, ?, ?, ?)",
                   (loan_id, bank_id, decision, notes, date))
        db.execute("UPDATE loan_applications SET status=? WHERE id=?", (decision, loan_id))
        db.commit()
        return redirect(url_for('dashboard_bank', bank_id=bank_id))
        
    application = db.execute('''
        SELECT l.*, c.name, c.phone, c.id as customer_id
        FROM loan_applications l 
        JOIN customers c ON l.customer_id = c.id
        WHERE l.id=?
    ''', (loan_id,)).fetchone()
    
    if application:
        bills = db.execute("SELECT * FROM bills WHERE customer_id=? ORDER BY paid_date DESC", (application['customer_id'],)).fetchall()
        savings = db.execute("SELECT * FROM savings WHERE customer_id=? ORDER BY date DESC", (application['customer_id'],)).fetchall()
        
        score = application['score']
        product = "Not ready — needs improvement"
        if score >= 70:
            product = "Working Capital / Emergency Loan"
        elif score >= 40:
            product = "Micro Loan with Monitoring"
            
        return render_template('loan_detail.html', app=application, bills=bills, savings=savings, product=product, bank_id=bank_id)
    return "Application not found"

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
