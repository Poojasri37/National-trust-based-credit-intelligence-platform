import { spawn } from 'child_process';

// Spawn the Python Flask app
const flaskProcess = spawn('python3', ['app.py'], { 
  stdio: 'inherit',
  env: { ...process.env, FLASK_RUN_PORT: '5000', FLASK_RUN_HOST: '0.0.0.0' }
});

flaskProcess.on('close', (code) => {
  console.log(`Flask process exited with code ${code}`);
  process.exit(code ?? 0);
});

flaskProcess.on('error', (err) => {
  console.error('Failed to start Flask process:', err);
  process.exit(1);
});
