const languageTexts = {
    en: "Regular bill payments show financial reliability. Maintaining savings demonstrates commitment to financial goals.",
    hi: "समय पर बिल भुगतान वित्तीय विश्वसनीयता दिखाता है। बचत बनाए रखना आपकी वित्तीय प्रतिबद्धता को दर्शाता है।",
    ta: "சரியான நேரத்தில் பில் கட்டுதல் நிதி நம்பகத்தன்மையை காட்டுகிறது. சேமிப்பை பராமரிப்பது உங்கள் நிதி இலக்கங்களுக்கான உங்கள் உறுதிப்பாட்டை காட்டுகிறது।",
    te: "సకాలంలో బిల్లు చెల్లించడం ఆర్థిక విశ్వసనీయతను చూపుతుంది. సేవింగ్‌లను నిర్వహించడం మీ ఆర్థిక లక్ష్యాలకు మీ నిబద్ధతను చూపుతుంది.",
    bn: "সময়মতো বিল পরিশোধ আর্থিক নির্ভরযোগ্যতা প্রদর্শন করে। সঞ্চয় বজায় রাখা আপনার আর্থিক লক্ষ্যগুলির প্রতি আপনার প্রতিশ্রুতি দেখায়।"
};

function updateLanguageExplanation() {
    const langSelect = document.getElementById('lang-select');
    const langExpl = document.getElementById('lang-explanation');
    if (langSelect && langExpl) {
        const lang = langSelect.value;
        langExpl.textContent = languageTexts[lang];
    }
}

function switchTab(event, tabName) {
    event.preventDefault();
    
    const contents = document.querySelectorAll('.tab-content');
    contents.forEach(content => content.classList.remove('active'));
    
    const links = document.querySelectorAll('.tab-link');
    links.forEach(link => link.classList.remove('active'));
    
    document.getElementById(tabName).classList.add('active');
    event.target.classList.add('active');
}

function filterApplications(filter) {
    const rows = document.querySelectorAll('.app-row');
    rows.forEach(row => {
        const likelihood = row.getAttribute('data-likelihood');
        if (filter === 'all' || likelihood.includes(filter)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    // Animate score bars
    const bars = document.querySelectorAll('.score-fill');
    bars.forEach(bar => {
        const width = bar.getAttribute('data-width');
        setTimeout(() => {
            bar.style.width = width + '%';
        }, 300);
    });

    // Initialize language explanation
    updateLanguageExplanation();

    // Filter functionality for bank dashboard
    const filterButtons = document.querySelectorAll('.filter-btn');
    const rows = document.querySelectorAll('.app-row');

    if(filterButtons && rows.length > 0){
        filterButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const filter = btn.getAttribute('data-filter');
                rows.forEach(row => {
                    const likelihood = row.getAttribute('data-likelihood');
                    if (filter === 'all' || likelihood.includes(filter)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
        });
    }
});
